package Introduction;

public class ParentClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
String s= "sowmya";
String s1 = new String("sowmya");

		
	Person p = new Person();
	p.hashCode();

	}

}
